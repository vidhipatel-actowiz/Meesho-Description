import time
import random
from evpn import ExpressVpnApi


def main():
    vpn = ExpressVpnApi()
    while True:
        locations = vpn._get_locations()
        target_locations = []
        Locc = locations['data']['locations']
        for loc in Locc:
            if loc.get('country_code') == 'US':
                target_locations.append(loc['id'])
        if target_locations:
            print("Available USA VPN Locations:", target_locations)
            random.shuffle(target_locations)
            for loc in target_locations:
                print(f"Connecting to USA server ID: {loc}")
                vpn.connect(loc)
                time.sleep(3600)
                print("Disconnecting...")
                vpn.disconnect()
                print("Disconnected from current server.")
        else:
            print("No USA VPN locations found.")
            break


if __name__ == "__main__":
    main()

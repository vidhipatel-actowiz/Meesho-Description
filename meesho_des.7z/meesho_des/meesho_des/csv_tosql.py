import pandas as pd
from sqlalchemy import create_engine
import db_config as db

# Define your file path and database connection details
# csv_file_path = r"D:\siraj\meesho_des\Inputs\snapdeal_map.csv"  # Replace with your CSV file path
csv_file_path = r"D:\siraj\meesho_des\Inputs\daily_product_links_685.csv"  # Replace with your CSV file path
# csv_file_path = r"D:\siraj\meesho_des\Inputs\Seller_product_links_28032025.csv"  # Replace with your CSV file path

# Database connection details
db_type = 'mysql+pymysql'  # Example for MySQL; adjust for your database type (e.g., 'sqlite', 'postgresql')
username = 'root'
password = 'actowiz'
host = 'localhost'  # 'localhost' if running on your local machine
port = '3306'  # Default for MySQL is '3306'
database = 'meesho_des'


# Table name where you want to store the data
csv_table_name = f'daily_product_links'  # Replace with your desired table name
# csv_table_name = f'seller_product_links_20250328'  # Replace with your desired table name

# Read the CSV file into a pandas DataFrame
csv_df = pd.read_csv(csv_file_path)

# Create the SQLAlchemy engine to connect to the SQL database
engine = create_engine(f'{db_type}://{username}:{password}@{host}:{port}/{database}')

# Store the DataFrame in the SQL table
csv_df.to_sql(csv_table_name, con=engine, if_exists='replace', index=False)

print(f"Data from {csv_file_path} has been successfully stored in the {csv_table_name} table in the {database} database.")
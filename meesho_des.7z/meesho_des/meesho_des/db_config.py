from datetime import datetime

# DATABASE DETAILS
db_host = 'localhost'
# db_host = '172.27.131.60'
db_user = 'root'
db_password = 'actowiz'
db_name = 'meesho_des'


current_week_daily = str(datetime.now().strftime("%Y%m%d"))

# -----------------------------------------------------------------
# current_week_daily = '20250721'

# For Daily
db_links_table_daily = f'daily_product_links'
db_data_table_daily = f'daily_meesho_pdp_data_{current_week_daily}'

# db_data_table_daily = f'daily_meesho_pdp_data_{current_week_daily}_tmp'

#Seller_meesho
# db_links_table_daily = f"seller_product_links_{current_week_daily}"
# db_data_table_daily = f"seller_product_data_{current_week_daily}"

# # -----------------------------------------------------------------

current_week = str(datetime.now().strftime("%Y%m%d"))
# current_week = '20250223'
db_links_table = f'product_links_{current_week}'
db_data_table = f'meesho_pdp_data_{current_week}'
# db_pin_data_table = f'meesho_pc_data_{current_week}'

template_table = f"template_{current_week}"

seller_db_links_table = "seller_links"
seller_db_pro_links_table = f"seller_product_links_{current_week}"
seller_db_pro_data_table = f"seller_product_data_{current_week}"
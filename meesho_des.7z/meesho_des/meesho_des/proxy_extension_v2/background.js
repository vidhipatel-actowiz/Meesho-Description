// Set proxy configuration
const config = {
    mode: "fixed_servers",
    rules: {
        singleProxy: {
            scheme: "http",
            host: "185.124.241.138",
            port: 12323
        },
        bypassList: ["localhost"]
    }
};

// Apply proxy settings
chrome.proxy.settings.set({ value: config, scope: "regular" }, () => {
    if (chrome.runtime.lastError) {
        console.error("Proxy settings failed:", chrome.runtime.lastError);
    } else {
        console.log("Proxy settings applied successfully.");
    }
});

// Handle authentication
function callbackFn(details) {
    console.log("Authentication required for:", details.url); // Debugging
    return {
        authCredentials: {
            username: "14a148fa21239",
            password: "ceae0888a2"
        }
    };
}

// Add listener for authentication
chrome.webRequest.onAuthRequired.addListener(
    callbackFn,
    { urls: ["<all_urls>"] },
    ['blocking']
);

// Debugging: Log proxy and auth events
chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
        console.log("Request initiated:", details.url); // Debugging
    },
    { urls: ["<all_urls>"] }
);

chrome.webRequest.onCompleted.addListener(
    (details) => {
        console.log("Request completed:", details.url); // Debugging
    },
    { urls: ["<all_urls>"] }
);

chrome.webRequest.onErrorOccurred.addListener(
    (details) => {
        console.error("Request error:", details.url, details.error); // Debugging
    },
    { urls: ["<all_urls>"] }
);
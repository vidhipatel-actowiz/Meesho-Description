import os
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError

# Initialize Slack client with your bot token
# SLACK_API_TOKEN = "xoxb-5271689174342-7736212918068-LP5mZIakRUFN906Fj3fqNb4g"  # Replace with your bot token
# SLACK_API_TOKEN = "xoxb-5271689174342-5352435442096-oKZGnBD7GxOkj69k35MMIXTC"  # Replace with your bot token
SLACK_API_TOKEN = "xoxb-5271689174342-5352435442096-I4d1ndX3gGUoeURtsIGdOxt5"  # Replace with your bot token
client = WebClient(token=SLACK_API_TOKEN)


def delete_message(channel_id, message_ts):
    try:
        response = client.chat_delete(
            channel=channel_id,
            ts=message_ts
        )
        print("Message deleted successfully.")
    except SlackApiError as e:
        print(f"Error deleting message: {e.response['error']}")


# Replace with the actual channel ID and message timestamp

link = 'https://actowizsolutions41121.slack.com/archives/C086LVC6BK4/p1753073348176629'
timestamp_from_link = link.split('/')[-1].replace('p', '')
SLACK_CHANNEL_ID = link.split('/')[-2]  # Replace with the channel ID where you want to upload the files

formatted_timestamp = timestamp_from_link[:-6] + '.' + timestamp_from_link[-6:]
print(formatted_timestamp)
# delete_message(SLACK_CHANNEL_ID, message_ts=message_timestamp)

delete_message(SLACK_CHANNEL_ID, formatted_timestamp)


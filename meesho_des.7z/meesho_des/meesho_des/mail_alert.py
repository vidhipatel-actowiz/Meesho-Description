import pymysql
import pandas as pd
import matplotlib.pyplot as plt
import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.mime.image import MIMEImage
import os

# 1. Global Config
DB_CONFIG = {
    "host": "172.27.131.60",
    "user": "root",
    "password": "actowiz",
    "database": "meesho_des"
}

EMAIL_CONFIG = {
    "sender": "sonuprajapati.actowiz@gmail.com",
    "receiver": "Sagar.Sonawane@actowizsolutions.com",
    "cc": [
        "vidhipatel.actowiz@gmail.com",
        "bansrichag.actowiz@gmail.com",
        "abhijeetmhasde.actowiz@gmail.com",
        "viveknagvanshi.actowiz@gmail.com",
        "swapnil.singh@actowizsolutions.com",
        "rahul.mishra@actowizsolutions.com",
        "rahulm.actowiz@gmail.com",
    ],
    "smtp_server": "smtp.gmail.com",
    "smtp_port": 587,
    "smtp_username": "sonuprajapati.actowiz@gmail.com",
    "smtp_password": "qatf bawk xzqh kbfm"  # App password
}

# 2. DB Connection
def get_db_connection():
    return pymysql.connect(**DB_CONFIG)

# 3. Get Daily Table Counts
def get_table_counts(cursor):
    today = datetime.date.today()
    prefix = today.strftime("daily_meesho_pdp_data_%Y%m")
    cursor.execute("SHOW TABLES")
    tables = [t[0] for t in cursor.fetchall() if t[0].startswith(prefix)]

    counts = {}
    for table in sorted(tables):
        cursor.execute(f"SELECT COUNT(*) FROM {table}")
        count = cursor.fetchone()[0]
        date_str = table.split('_')[-1]
        date_label = datetime.datetime.strptime(date_str, "%Y%m%d").strftime("%d-%b")
        counts[date_label] = count
    return counts

# 4. Generate Excel for Today
def generate_excel_for_today(cursor):
    today_table = f"daily_meesho_pdp_data_{datetime.date.today().strftime('%Y%m%d')}"
    cursor.execute(f"SELECT * FROM {today_table}")
    df = pd.DataFrame(cursor.fetchall(), columns=[desc[0] for desc in cursor.description])
    filename = f"{today_table}.xlsx"
    df.to_excel(filename, index=False)
    return filename

# 5. Generate Bar Chart
def generate_bar_chart(counts):
    plt.figure(figsize=(12, 6))
    bars = plt.bar(counts.keys(), counts.values(), color='skyblue')
    plt.title("Daily PDP Record Count")
    plt.xlabel("Date")
    plt.ylabel("Count")
    plt.xticks(rotation=45, ha='right')
    for bar in bars:
        yval = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2, yval + 1, yval, ha='center', fontsize=8)
    plt.tight_layout()
    chart_file = "daily_pdp_chart.png"
    plt.savefig(chart_file)
    plt.close()
    return chart_file

# 6. Build Email HTML
def build_html(today_count, yesterday_count, total_count, out_of_stock):
    today = datetime.date.today().strftime('%d-%b-%Y')
    return f"""
    <html>
      <body>
        <h2>Meesho Description - Daily Report</h2>
        <table border="1" cellpadding="8" cellspacing="0" style="border-collapse: collapse; font-family: Arial; width: 400px;">
            <tr><th align="left">Project Name</th><td>Meesho Description</td></tr>
        </table><br>

        <h3>Count Summary</h3>
        <table border="1" cellpadding="8" cellspacing="0" style="border-collapse: collapse; font-family: Arial; width: 400px;">
            
            <tr><th align="left">Yesterday's Count</th><td>{yesterday_count}</td></tr>
            <tr><th align="left">Today's Count</th><td>{today_count}</td></tr>
            <tr><th align="left">Today - Out of Stock</th><td>{out_of_stock}</td></tr>
            <tr><th align="left">Total Count</th><td>685</td></tr>
        </table><br>

        <h3>Daily Count Graph</h3>
        <img src="cid:chartimage"><br>
        <small>(Graph shows daily record count scraped for this month)</small>
      </body>
    </html>
    """

# 7. Send Email
def send_email(html, chart_file, excel_file):
    msg = MIMEMultipart("related")
    msg["Subject"] = f"Meesho Description - Daily Report ({datetime.date.today().strftime('%d-%b-%Y')})"
    msg["From"] = EMAIL_CONFIG["sender"]
    msg["To"] = EMAIL_CONFIG["receiver"]
    msg["Cc"] = ", ".join(EMAIL_CONFIG["cc"])

    # Attach HTML
    msg.attach(MIMEText(html, "html"))

    # Attach chart image
    with open(chart_file, 'rb') as f:
        img = MIMEImage(f.read())
        img.add_header('Content-ID', '<chartimage>')
        img.add_header('Content-Disposition', 'inline', filename=chart_file)
        msg.attach(img)

    # Attach Excel
    with open(excel_file, 'rb') as f:
        attachment = MIMEApplication(f.read(), _subtype="xlsx")
        attachment.add_header('Content-Disposition', 'attachment', filename=os.path.basename(excel_file))
        msg.attach(attachment)

    try:
        with smtplib.SMTP(EMAIL_CONFIG["smtp_server"], EMAIL_CONFIG["smtp_port"]) as server:
            server.starttls()
            server.login(EMAIL_CONFIG["smtp_username"], EMAIL_CONFIG["smtp_password"])
            server.sendmail(EMAIL_CONFIG["sender"], [EMAIL_CONFIG["receiver"]] + EMAIL_CONFIG["cc"], msg.as_string())
        print("✅ Email sent successfully!")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")

# 8. Main Flow
def main():
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        counts = get_table_counts(cursor)
        today = datetime.date.today().strftime("%d-%b")
        yesterday = (datetime.date.today() - datetime.timedelta(days=1)).strftime("%d-%b")

        today_count = counts.get(today, 0)
        yesterday_count = counts.get(yesterday, 0)
        total_count = sum(counts.values())
        out_of_stock = 685 - today_count

        chart_file = generate_bar_chart(counts)
        excel_file = generate_excel_for_today(cursor)
        html = build_html(today_count, yesterday_count, total_count, out_of_stock)

        send_email(html, chart_file, excel_file)

    finally:
        cursor.close()
        conn.close()

# 9. Run
if __name__ == "__main__":
    main()

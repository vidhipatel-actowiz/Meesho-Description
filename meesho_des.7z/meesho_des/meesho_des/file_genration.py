import json
import os.path
import sys
# from slack_bot_functions import send_slack_message
from datetime import datetime
from pathlib import Path
from slack_sdk import WebClient
import ssl
import pandas as pd
import sqlalchemy
import meesho_des.db_config as db
from pathlib import Path

slack_bot_credentials_dict: dict = json.loads(Path(r"D:\siraj\meesho_des\meesho_des\slack_bot_credentials.json").read_text(encoding="utf-8"))
slack_bot_token: str = slack_bot_credentials_dict.get('slack_bot_token_dict', {}).get('slack_bot_token', 'N/A')  # Replace with your bot token
daily_msgs_channel_id: str = slack_bot_credentials_dict.get('daily_msgs_channel_id_dict', {}).get('daily_msgs_channel_id', 'N/A')  # Replace with your channel id
official_channel_id: str = slack_bot_credentials_dict.get('official_channel_id_dict', {}).get('official_channel_id', 'N/A')  # Replace with your channel id

def send_slack_message(slack_bot_token, message, channel_id):
    """Send a message to Slack channel."""
    slack_client = WebClient(token=slack_bot_token)
    try:
        slack_client.chat_postMessage(channel=channel_id, text=message)
        print(f"Message sent to Slack: {message}")
    except Exception as e:
        slack_client.chat_postMessage(channel=channel_id, text=f"Failed to send message to Slack: {e}")
        print(f"Failed to send message to Slack: {e}")

# def file_generate():
#     # Database connection setup
#     db_url = f"mysql+pymysql://{db.db_user}:{db.db_password}@{db.db_host}/{db.db_name}"  # Replace placeholders with your database details
#     engine = sqlalchemy.create_engine(db_url)
#
#     # SQL table read
#     table_name = f"{db.db_data_table}"  # Replace with your table name
#     # table_name = 'meesho_pdp_data_20241231_jewe'
#     query = f"SELECT * FROM {table_name}"
#
#
#     # Read table into DataFrame
#     df = pd.read_sql(query, engine)
#     df = df.replace(r'^\s*$', None, regex=True)
#     df['Product_Sku_Name'] = df['Product_Sku_Name'].str.replace(r'\s+', ' ', regex=True).str.strip()
#
#     # Drop the unwanted column
#     if 'Product_Pin_PageSave_Status' in df.columns:
#         df = df.drop(columns=['Product_Pin_PageSave_Status'])
#     if 'daily' in table_name:
#         df = df.drop(columns=['Category_URL'])
#
#     # Fill missing values with "N/A"
#     # df.fillna("N/A", inplace=True)
#
#     # Write to Excel file
#     # output_file = f"D:\siraj\meesho_des\meesho_des\output\Daily_Meesho_Desc_Data_{db.current_week}.xlsx"  # Name of the Excel file
#     output_file = rf"D:\siraj\meesho_des\meesho_des\output\Daily_Meesho_Desc_Data_{db.current_week}.xlsx"
#     # output_file = f"D:\siraj\meesho_des\meesho_des\output\Categories_Jewellery.xlsx"  # Name of the Excel file
#     with pd.ExcelWriter(path=output_file, engine='xlsxwriter',
#             engine_kwargs={"options": {'strings_to_urls': False}}) as writer:
#         df.to_excel(writer, index=False)
#
#     print(f"Excel file generated: {output_file}")

def file_generate_daily():
    # Database connection setup
    db_url = f"mysql+pymysql://{db.db_user}:{db.db_password}@{db.db_host}/{db.db_name}"  # Replace placeholders with your database details
    engine = sqlalchemy.create_engine(db_url)

    # SQL table read
    table_name = f"{db.db_data_table_daily}"  # Replace with your table name
    # table_name = 'meesho_pdp_data_20241231_jewe'
    query = f"SELECT * FROM {table_name}"


    # Read table into DataFrame
    df = pd.read_sql(query, engine)
    df = df.replace(r'^\s*$', None, regex=True)
    df['Product_Sku_Name'] = df['Product_Sku_Name'].str.replace(r'\s+', ' ', regex=True).str.strip()

    # Drop the unwanted column
    if 'Product_Pin_PageSave_Status' in df.columns:
        df = df.drop(columns=['Product_Pin_PageSave_Status'])
    if 'daily' in table_name:
        df = df.drop(columns=['Category_URL'])

    # Fill missing values with "N/A"
    # df.fillna("N/A", inplace=True)

    # Write to Excel file
    output_file_xlsx = rf"D:\siraj\meesho_des\meesho_des\output_daily\Daily_Meesho_Desc_Data_{db.current_week_daily}.xlsx"
    # output_file_xlsx = f"D:\siraj\meesho_des\meesho_des\output_daily\Seller_Meesho_Desc_Data_{db.current_week_daily}.xlsx"  # Name of the Excel file
    # output_file = f"D:\siraj\meesho_des\meesho_des\output\Categories_Jewellery.xlsx"  # Name of the Excel file
    with pd.ExcelWriter(path=output_file_xlsx, engine='xlsxwriter',
            engine_kwargs={"options": {'strings_to_urls': False}}) as writer:
        df.to_excel(writer, index=False)
    print(f"Excel file generated: {output_file_xlsx}")

    # Write to CSV file
    output_file_CSV = rf"D:\siraj\meesho_des\meesho_des\output_daily\Daily_Meesho_Desc_Data_{db.current_week_daily}.csv"
    # output_file_CSV = f"D:\siraj\meesho_des\meesho_des\output_daily\Seller_Meesho_Desc_Data_{db.current_week_daily}.csv"  # CSV file path
    df.to_csv(output_file_CSV, index=False, encoding='utf-8-sig')
    print(f"CSV file generated: {output_file_CSV}")

    if os.path.exists(output_file_xlsx):
        print(f'{output_file_xlsx} exists, sending on slack...')
        # send_slack_message(slack_bot_token=slack_bot_token, channel_id=daily_msgs_channel_id, message=f'{report_name} exists, sending on slack...')

        # client = WebClient(token=slack_bot_token)
        ssl_context = ssl.create_default_context()
        client = WebClient(token=slack_bot_token, ssl=ssl_context, timeout=600)
        # client.files_upload_v2()
        try:
            print(output_file_xlsx.split("\\")[-1])
            comp = f"Sy_Meesho_Description_Daily : {db.current_week_daily}"
            client.files_upload_v2(
                channel=official_channel_id,
                # channel=daily_msgs_channel_id,
                file=output_file_CSV,
                filename=output_file_CSV.split("\\")[-1],
                initial_comment=f"<@U059KAHPHQV>,<@U0772G42F8T>\n\nCC : <@U073L80NUTE>, <@U05AC0155J4>\n\n{comp.capitalize()}",
                # initial_comment=f"\n\n{comp.capitalize()}",U073L80NUTE
            )
            # client.files_upload_v2(
            #     channel=official_channel_id,
            #     # channel=daily_msgs_channel_id,
            #     file=output_file_CSV,
            #     # initial_comment=f"\n\n{comp.capitalize()}",U073L80NUTE
            # )
        except Exception as e:
            print(e)
        print("File Sent in channel.")
        # send_slack_message(slack_bot_token=slack_bot_token, channel_id=daily_msgs_channel_id, message="File Sent in channel Successful.")
    else:
        print(f'{output_file_xlsx} does not exists!')

# file_generate()
# file_generate_daily()
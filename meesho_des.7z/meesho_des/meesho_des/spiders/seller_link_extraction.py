import math
from datetime import datetime
from typing import Iterable
import hashlib
import scrapy
from scrapy import Request
from scrapy.cmdline import execute
import pymysql
import meesho_des.db_config as db
import os
import random
import gzip
from scrapy import Selector
from meesho_des.items import *
import json
import urllib.parse
import re
from meesho_des.headers import *
import requests
from scrapy.http import HtmlResponse


class PdpSpiderSpider(scrapy.Spider):
    name = "seller_product_link_spider"
    # allowed_domains = ["www.meesho.com"]
    # start_urls = ["https://www.meesho.com/"]


    def __init__(self,start='',end=''):
        super().__init__()
        self.start = start
        self.end = end

        # DATABASE CONNECTION
        self.con = pymysql.connect(host=db.db_host, user=db.db_user, password=db.db_password, db=db.db_name,autocommit=True)
        self.cursor = self.con.cursor()
        self.con.autocommit(True)

        self.folder_location = f"D:/Meesho/meesho_des/seller_pdp_page_save/{db.current_week}/"
        # Create folder if not exits
        os.makedirs(self.folder_location, exist_ok=True)

        scrape_do_token='4d6a0e0cab5d4b79811b69533059e6b1eccb3b7b628'
        # scrape_do_token='aa48e53ef4934d95a56acecacaec8fe454ebf634a98'
        self.scrape_proxy = {
            "http": f"http://{scrape_do_token}:geoCode=us@proxy.scrape.do:8080",
            "https": f"http://{scrape_do_token}:geoCode=us@proxy.scrape.do:8080"
        }

        # API_TOKEN = 'aa48e53ef4934d95a56acecacaec8fe454ebf634a98'
        API_TOKEN = '4d6a0e0cab5d4b79811b69533059e6b1eccb3b7b628'
        self.PROXY = f'https://api.scrape.do/?token={API_TOKEN}&url='

    def generate_hash_id(self,url):
        print(type(url))
        hashid = hashlib.md5(str(url).encode()).hexdigest()[:16]
        return hashid

    def clean_url(self,url: str) -> str:
        parsed_url = urllib.parse.urlparse(url)
        decoded_path = urllib.parse.unquote(parsed_url.path)  # Decode URL-encoded characters
        formatted_path = re.sub(r"[^a-zA-Z0-9/]+", "-", decoded_path).strip(
            "-").lower()  # Replace special chars with '-'
        return f"{parsed_url.scheme}://{parsed_url.netloc}/{formatted_path}"  # Reconstruct URL

    def start_requests(self):
        query = f"select * FROM {db.seller_db_links_table} where status='Pending' and `Id` between {self.start} and {self.end};"
        self.cursor.execute(query)
        query_results = self.cursor.fetchall()
        self.logger.info(f"\n\n\nTotal Results ...{len(query_results)}\n\n\n", )

        for i in query_results:
            index_id = i[0]
            seller_data_name = str(i[1]).strip()
            seller_url_link = str(i[2]).strip()

            if '/search?' in seller_url_link or '/p/' in seller_url_link:
                update_link_table = f"UPDATE {db.seller_db_links_table} set STATUS='Not seller link' where `Id` = {index_id}"
                self.cursor.execute(update_link_table)
                self.con.commit()
                # return None

            # seller_url = i[1]
            page_no = 1

            if '?' in seller_url_link:
                seller_url = seller_url_link.split('?')[0]
            else:
                seller_url = seller_url_link

            seller_name = seller_url.split('/')[-1].split('?')[0]
            file_path = self.folder_location + seller_name + f'_{page_no}' + f".html.gz"
            if not os.path.exists(file_path):
                seller_req_url = seller_url  + f'?page={page_no}'
                yield scrapy.Request(
                    url= self.PROXY + seller_req_url,
                    headers=headers,
                    cookies=cookies,
                    cb_kwargs={
                        "page_read": False,
                        "index_id": index_id,
                        "seller_data_name" : seller_data_name,
                        "store_name" : seller_name,
                        "seller_url" : seller_url,
                        "seller_link" : seller_url_link,
                        "page_no" : page_no,
                        "file_path" : file_path,
                        "require_pages" : 0
                    },
                    # meta={"proxy": self.scrape_proxy},
                    dont_filter=True
                )
            else:
                yield scrapy.Request(url=f'file:///{file_path}',
                                     cb_kwargs={
                                         "page_read": True,
                                         "index_id": index_id,
                                         "seller_data_name": seller_data_name,
                                         "store_name": seller_name,
                                         "seller_url": seller_url,
                                         "seller_link": seller_url_link,
                                         "page_no": page_no,
                                         "file_path": file_path,
                                         "require_pages": 0
                                     },
                                     meta={"impersonate": random.choice(["chrome110", "edge99", "safari15_5"])},
                                     dont_filter=True)
            # break


    def parse(self, response,**kwargs):
        print("Parse Calling...")
        page_read = kwargs['page_read']
        index_id = kwargs['index_id']
        seller_data_name = kwargs['seller_data_name']
        store_name = kwargs['store_name']
        seller_url = kwargs['seller_url']
        seller_link = kwargs['seller_link']
        page_no = kwargs['page_no']
        file_path = kwargs['file_path']
        require_pages = kwargs['require_pages']

        if response.status in [403, 429]:
            # Copy the request for retry
            request = response.request.copy()
            # Rotate proxy
            # request.meta['proxy'] = self.PROXY
            # self.logger.info(f"Retrying with new proxy: {new_proxy}")
            # Rotate user agent (impersonate)
            request.meta.update({"impersonate": random.choice(["chrome110", "edge99", "safari15_5"])})
            request.dont_filter = True  # Avoid Scrapy duplicate request filtering
            yield request
            return None

        if page_read:
            response = gzip.decompress(response.body)
            data = response.split(b'id="__NEXT_DATA__" type="application/json">')[1].split(b"</script>")[0]
        else:
            data = response.body.split(b'id="__NEXT_DATA__" type="application/json">')[1].split(b"</script>")[0]
            with gzip.open(file_path, "wb") as f:
                f.write(response.body)

        try:
            try:
                # product_data_list = json.loads(data)['props']['pageProps']['initialState']['shopListing']['listing']['products'][0]['products']
                product_data_list = json.loads(data).get('props',{}).get('pageProps',{}).get('initialState',{}).get('shopListing',{}).get('listing',{}).get('products',[])[0].get('products',[])
            except:
                product_data_list = json.loads(data).get('props',{}).get('pageProps',{}).get('initialState',{}).get('shopListing',{}).get('listing',{}).get('products',[])

        except (IndexError, KeyError, json.JSONDecodeError):
            return {"URL": seller_url, "Message": "Page not found."}

        if product_data_list:

            # try:
            #     additional_info = {}
            #     shop_value_data = json.loads(data)['props']['pageProps']['initialState']['shop']['shopInfo']['shopProfile']['profile']['shop_value_props']
            #     supplier_rating_count= shop_value_data[0]['rating']['count']
            #     supplier_rating = shop_value_data[0]['rating']['average_rating']
            #     supplier_followers = shop_value_data[1]['follower']['count']
            #     supplier_product_count = shop_value_data[2]['product']['count']
            #     additional_info['Shop Rating'] = supplier_rating
            #     additional_info['Shop Rating Count'] = supplier_rating_count
            #     additional_info['Shop Followers'] = supplier_followers
            #     additional_info['Shop Product'] = supplier_product_count
            # except Exception as e:
            #     print(e)
            #     additional_info = "N/A"
            try:
                product_count = json.loads(data)['props']['pageProps']['initialState']['shopListing']['listing']['productsCount']
                per_page_record = 20
                # no_of_pages = round(product_count / per_page_record)
                no_of_pages = math.ceil(product_count / per_page_record)
                require_pages = no_of_pages
                next_page_status = False
                if page_no < no_of_pages:
                    next_page_status = True

                total_result = product_count
                total_pages = no_of_pages
                current_pages = page_no
                next_page = next_page_status
            except:
                product_count = 0
                no_of_pages = 0
                next_page = False

            for i in range(len(product_data_list)):
                try:
                    product_name = product_data_list[i]['name']
                except:
                    product_name = "N/A"

                slug = product_data_list[i]['slug']
                product_id = product_data_list[i]['product_id']
                product_link = f'https://www.meesho.com/{slug}/p/{product_id}'

                item = MeeshoDesSellerLinkItem()
                item['seller_name'] = seller_data_name
                item['base_url'] = seller_link
                item['product_url'] = product_link
                yield item
                    # break

            if next_page:
                page_no += 1
                if page_no == 38:
                    print("Wait...")
                if 'page' not in seller_url:
                    if '?' not in seller_url:
                        next_page_url = f"{seller_url}?page={page_no}"
                    else:
                        next_page_url = f"{seller_url}&page={page_no}"
                    next_file_path = self.folder_location + store_name + f'_{page_no}' + f".html.gz"
                    if not os.path.exists(next_file_path):
                        # url = "https://www.meesho.com/s/p/" + sku
                        yield scrapy.Request(
                            url= self.PROXY + next_page_url,
                            headers=headers,
                            cookies=cookies,
                            cb_kwargs={
                                "page_read": False,
                                "index_id": index_id,
                                "store_name": store_name,
                                "seller_data_name": seller_data_name,
                                "seller_url": seller_url,
                                "seller_link": seller_link,
                                "page_no": page_no,
                                "file_path": next_file_path,
                                "require_pages": require_pages
                            },
                            callback=self.parse,
                            # meta={'proxy': self.scrape_proxy['http']},
                            # meta={'proxy': f'http://f595b623fd4843888dfde0002b791b0dab104b63f0d:geoCode=us@proxy.scrape.do:8080'},
                            dont_filter=True
                        )
                    else:
                        yield scrapy.Request(url=f'file:///{next_file_path}',
                                             cb_kwargs={
                                                 "page_read": True,
                                                 "index_id": index_id,
                                                 "store_name": store_name,
                                                 "seller_data_name": seller_data_name,
                                                 "seller_url": seller_url,
                                                 "seller_link": seller_link,
                                                 "page_no": page_no,
                                                 "file_path": next_file_path,
                                                 "require_pages": require_pages
                                             },
                                             callback=self.parse,
                                             meta={"impersonate": random.choice(["chrome110", "edge99", "safari15_5"])},
                                             dont_filter=True)
            else:
                update_link_table = f"UPDATE {db.seller_db_links_table} set STATUS='Done' where `Id` = {index_id}"
                self.cursor.execute(update_link_table)
                self.con.commit()

        else:
            print('No Products available in List ... ')
            if page_no == 1:
                update_link_table = f"UPDATE {db.seller_db_links_table} set STATUS='0 Count Fetch' where `Id` = {index_id}"
                self.cursor.execute(update_link_table)
                self.con.commit()
            elif page_no >= require_pages:
                update_link_table = f"UPDATE {db.seller_db_links_table} set STATUS='Done' where `Id` = {index_id}"
                self.cursor.execute(update_link_table)
                self.con.commit()


if __name__ == '__main__':
    execute("scrapy crawl seller_product_link_spider -a start=100 -a end=947".split())
    # execute("scrapy crawl seller_pdp_spider -a start=1 -a end=112".split())

import json
import os
import random
import re
from datetime import datetime, timedelta
from typing import Union
from meesho_des.headers import *
from parsel import Selector
from scrapy import Spider
from scrapy.http import HtmlResponse
from twisted.internet.defer import Deferred
from meesho_des.items import *
import pymysql
import scrapy
from scrapy.cmdline import execute
import meesho_des.db_config as db
import gzip
import hashlib
from lxml import etree
from meesho_des.file_genration import file_generate_daily


def normalize_spaces(text):
    return '\n'.join(re.sub(r'\s+', ' ', line).strip() for line in text.splitlines() if line.strip())

class ProductDataSpider(scrapy.Spider):
    name = "product_data_des_daily"
    handle_httpstatus_list = [403, 429, 400, 410]
    # folder_location = f"D:/Meesho/meesho_des"
    # folder_location = f"C:/Meesho/meesho_des/pdp_page_save/"
    errors = list()

    DATE = db.current_week_daily
    # DATE = '20250108'
    # folder_location = f"D:/Meesho/meesho_des/seller_pdp_page_save/{DATE}/"
    folder_location = f"D:/Meesho/meesho_des/pdp_page_save/{DATE}/"
    # folder_location = f"C:/Meesho/meesho_des/pdp_page_save/{DATE}/"
    # Create folder if not exits
    os.makedirs(folder_location, exist_ok=True)


    # proxy = f"https://api.scrape.do/?token=aa48e53ef4934d95a56acecacaec8fe454ebf634a98&url="
    # proxy = f"https://api.scrape.do/?token=b8ac1a5cb3b84e3b93485b56a9ee46bd5159f900d3c&url="
    # proxy = f"https://api.scrape.do/?token=6e4e6463b1964d9a8b56aac77d9808a41224f8cc736&url="
    proxy = f"https://api.scrape.do/?token=b8ac1a5cb3b84e3b93485b56a9ee46bd5159f900d3c&url="

    # API_TOKEN = '6e4e6463b1964d9a8b56aac77d9808a41224f8cc736'
    # API_TOKEN = '2d76727898034978a3091185c24a5df27a030fdc3f8'
    API_TOKEN = '3b51c7dae74a4f8cbb7d5d45930eea8797ac5cf6bde'
    # API_TOKEN = '6e4e6463b1964d9a8b56aac77d9808a41224f8cc736'
    PROXY = f'https://api.scrape.do/?token={API_TOKEN}&url='
    def __init__(self, name=None, start='', end='', **kwargs):
        super().__init__(name, **kwargs)
        # DATABASE SPECIFIC VALUES
        self.start = start
        self.end = end

        # DATABASE CONNECTION
        self.con = pymysql.connect(host=db.db_host, user=db.db_user, password=db.db_password, db=db.db_name, autocommit=True)
        self.cursor = self.con.cursor()
        self.con.autocommit(True)
        self.name = 'product_data_des_daily'

    def assign_category_names(self,a):
        # Ensure the list has at least 2 elements
        if len(a) < 2:
            raise ValueError("The list must have at least 2 elements.")

        # Supercategory_Name is always the first two elements
        supercategory_name = " & ".join(a[:2])

        # Subcategory_Name includes elements from the second to the second-to-last
        if len(a) > 2:
            subcategory_name = " & ".join(a[1:-1])
        else:
            subcategory_name = a[1]  # If only two elements, Subcategory_Name = second element

        # Category_name is always the last element
        category_name = a[-1]

        return supercategory_name, subcategory_name, category_name

    def get_date_suffix(self,day):
        """Determine the ordinal suffix for a given day."""
        if 11 <= day <= 13:  # Special cases for 11th, 12th, 13th
            return "th"
        if day % 10 == 1:
            return "st"
        if day % 10 == 2:
            return "nd"
        if day % 10 == 3:
            return "rd"
        return "th"
    def get_delivery_info(self):
        # List of possible day differences
        days_range = [7, 8, 9, 10]

        # Choose a random day difference
        days_difference = random.choice(days_range)

        # Calculate the delivery date
        today = datetime.now()
        # today = datetime(2025, 1, 7, 14, 13, 12, 567716)
        delivery_date = today + timedelta(days=days_difference)

        # Format the delivery date
        delivery_day = delivery_date.strftime("%A")  # Full day name
        delivery_date_number = delivery_date.day  # Numeric day of the month
        delivery_month = delivery_date.strftime("%b")  # Abbreviated month name

        # Get the correct suffix for the day
        suffix = self.get_date_suffix(delivery_date_number)

        # Generate the delivery message
        delivery_message = f"Delivery by {delivery_day}, {delivery_date_number}{suffix} {delivery_month}"

        # Return the message and the number of days difference
        return delivery_message, days_difference
    def generate_hash_id(self,restaurant_url):
        print(type(restaurant_url))
        hashid = hashlib.md5(str(restaurant_url).encode()).hexdigest()[:6]
        return hashid

    def start_requests(self):
        query = f"select * FROM {db.db_links_table_daily} where status='pending' and `index` between {self.start} and {self.end};"
        self.cursor.execute(query)
        query_results = self.cursor.fetchall()
        self.logger.info(f"\n\n\nTotal Results ...{len(query_results)}\n\n\n", )

        for i in query_results:
            #TODO :: ********* for Home Page Product Data **********
            # index_id = i[0]
            # product_link = i[1]
            # category_URL = "NA"
            # Supercategory_Name = "NA"
            # Category_name = "NA"
            # Subcategory_Name = "NA"

            #TODO :: ********* for Seller page Product Data **********
            index_id = i[0]
            seller_name = i[1]
            category_URL = i[2]
            product_link = i[3]
            Supercategory_Name = "NA"
            Category_name = "NA"
            Subcategory_Name = "NA"
            # hash_url = category_URL + product_link

            # # #TODO :: ********* for Category wise Product Data **********
            # index_id = i[0]
            # Supercategory_Name = i[1]
            # Category_name = i[2]
            # Subcategory_Name = i[3]
            # category_URL = i[4]
            # product_link = i[5]

            if not product_link:
                continue
            product_url = product_link.strip()


            # # #For Category Data
            # sku = product_url.split('/')[-1].replace('?utm_source=s','')

            # For Seller Data
            sku = product_url.split('/p/')[-1].split('?')[0]

            # # For Home page URL Data
            # sku = product_url.split('/p/')[-1]
            # if '?' in sku:
            #     sku = sku.split('?')[0]


            if not os.path.exists(self.folder_location + sku + ".html.gz"):
                url = "https://www.meesho.com/s/p/" + sku
                # new_proxy = random.choice(self.proxies)
                yield scrapy.Request(
                    # url=self.PROXY + url,
                    url=url,
                    headers=headers,
                    cookies=cookies,
                    cb_kwargs={
                        "page_name": sku,
                        "product_url":product_url,
                        "seller_name" : seller_name,
                        "page_read": False,
                        "Supercategory_Name":Supercategory_Name,
                        "Category_name":Category_name,
                        "Subcategory_Name":Subcategory_Name,
                        "category_URL" : category_URL,
                        "index_id": index_id,
                        "product_link" : product_link
                    },
                    # meta={"proxy": new_proxy},
                    dont_filter=True
                )
            else:
                yield scrapy.Request(url=f'file:///{self.folder_location + sku + ".html.gz"}',
                                     cb_kwargs={
                                         "page_name": sku,
                                         "product_url": product_url,
                                         "seller_name": seller_name,
                                         "page_read": True,
                                         "Supercategory_Name": Supercategory_Name,
                                         "Category_name": Category_name,
                                         "Subcategory_Name": Subcategory_Name,
                                         "category_URL": category_URL,
                                         "index_id": index_id,
                                         "product_link": product_link
                                     },
                                     meta={"impersonate": random.choice(["chrome110", "edge99", "safari15_5"])},
                                     dont_filter=True)
            # break

    def parse(self, response, **kwargs):
        sku = kwargs['page_name']
        product_url = kwargs['product_url']
        product_link = kwargs['product_link']
        Supercategory_Name = kwargs['Supercategory_Name']
        Category_name = kwargs['Category_name']
        Subcategory_Name = kwargs['Subcategory_Name']
        category_URL = kwargs['category_URL']
        seller_name = kwargs['seller_name']

        index_id = kwargs['index_id']

        if response.status in [403, 429]:
            # Copy the request for retry
            request = response.request.copy()
            # Rotate proxy
            new_proxy = random.choice(self.proxies)
            request.meta['proxy'] = new_proxy
            self.logger.info(f"Retrying with new proxy: {new_proxy}")
            # Rotate user agent (impersonate)
            # request.meta.update({"impersonate": random.choice(["chrome110", "edge99", "safari15_5"])})
            request.dont_filter = True  # Avoid Scrapy duplicate request filtering
            yield request
            return None
        file_path = self.folder_location + sku + f".html.gz"
        if kwargs['page_read']:
            html_content = gzip.open(file_path, 'rt', encoding="utf-8", errors="replace").read()
            response = Selector(text=html_content)
            data = html_content.split('id="__NEXT_DATA__" type="application/json">')[1].split("</script>")[0]
            # response = gzip.decompress(response.body)
            # data = response.split(b'id="__NEXT_DATA__" type="application/json">')[1].split(b"</script>")[0]
        else:
            html_content = response.text
            data = response.body.split(b'id="__NEXT_DATA__" type="application/json">')[1].split(b"</script>")[0]
            # Writing the Gzip file safely
            with gzip.open(file_path, "wb") as f:
                f.write(response.body)

            if response.status == 410:
                html_content = response.text
                if 'This product is out of stock' in html_content:
                    status = "Out Of Stock"
                    oos_query = f"update {db.db_links_table_daily} set `status` = '{status}' where `index` = '{index_id}'"
                    try:
                        self.cursor.execute(oos_query)
                    except Exception as e:
                        print(e)

        if Supercategory_Name == "NA" or Subcategory_Name == "NA" or Category_name == "NA":
            list_of_categories = response.xpath('//*[@id="__next"]//ul[contains(@class,"Breadcrum")]//li/a//text()').getall()
            print(list_of_categories)
            if list_of_categories:
                cate = self.assign_category_names(list_of_categories)
                Supercategory_Name = cate[0]
                Category_name = cate[1]
                Subcategory_Name = cate[2]
            else:
                cate_data = json.loads(data)['props']['pageProps']['initialState']['product']['details']['data']
                if cate_data and 'This product is out of stock' not in html_content:
                    cate = cate_data.get('catalog',{}).get('sub_sub_category_name')
                    #"catalog.sub_sub_category_name"
                    Supercategory_Name = cate
                    Category_name = cate
                    Subcategory_Name = cate


        # response = Selector(text=response_text)
        status = "pending"
        data = json.loads(data)['props']['pageProps']['initialState']['product']['details']['data']
        if data:
            if data['valid']:
                if 'suppliers' not in data:
                    return None
                supplier = data['suppliers'][0]
                supplier_id = str(supplier['id'])
                SKU_URL_MEESHO = data['meta_info']['canonical_url']
                product_price = 0
                status = "Done"
                try:
                    mrp = data['mrp_details']['mrp']
                except:
                    mrp = None
                try:
                    original_price = data['original_price']
                except:
                    original_price = None
                try:
                    discounted_price = data['price']
                except:
                    discounted_price = None
                try:
                    discount_percentage = data['discount']
                except:
                    discount_percentage = None

                if not original_price and discounted_price:
                    original_price = discounted_price
                elif mrp and not original_price and not discounted_price:
                    original_price = mrp
                    discounted_price = mrp

                try:
                    rating_count_map = data['review_summary']['data']['rating_count_map']
                    if rating_count_map:
                        # Mapping of keys to labels
                        key_mapping = {
                            "1": "Poor",
                            "2": "Average",
                            "3": "Good",
                            "4": "Very Good",
                            "5": "Excellent"
                        }
                        # Replace keys with labels
                        rating_count_map = {key_mapping[key]: value for key, value in rating_count_map.items()}
                        rating_count_map = json.dumps(rating_count_map)
                except Exception as e:
                    print(e)
                    rating_count_map = "N/A"

                try:
                    Product_Avg_Rating = data['review_summary']['data']['average_rating']
                except:
                    Product_Avg_Rating = 0

                try:
                    Product_Rating_Count = data['review_summary']['data']['rating_count']
                except:
                    Product_Rating_Count = 0
                try:
                    Product_Review_Count = data['review_summary']['data']['review_count']
                except:
                    Product_Review_Count = 0
                try:
                    Seller_Avg_Rating = data['suppliers'][0]['average_rating']
                except:
                    Seller_Avg_Rating =0
                try:
                    Seller_Rating_Count = data['suppliers'][0]['rating_count']
                except:
                    Seller_Rating_Count = 0
                try:
                    Seller_Followers_Count = data['suppliers'][0]['shop_value_props'][1]['follower']['count']
                except:
                    Seller_Followers_Count = 0
                try:
                    Seller_Product_Count = data['suppliers'][0]['shop_value_props']
                    # Iterate through the list to find the 'product' type and get its count
                    Seller_Product_Count = next(item["product"]["count"] for item in Seller_Product_Count if item["type"] == "product")
                except:
                    Seller_Product_Count = 0


                seller_handle = data['suppliers'][0]['handle']
                seller_url = f'https://www.meesho.com/{seller_handle}?ms=2'
                # ['props']['pageProps']['initialState']['product']['details']['data']

                inventory_list = data['suppliers'][0]['inventory']
                if inventory_list:
                    size_variant = []
                    for i in range(len(inventory_list)):
                        size = inventory_list[i]['variation']['name']
                        size_variant.append(size)
                    size_variant = ' | '.join(size_variant)
                else:
                    size_variant = ' | '.join(data['variations'])

                # Step 1: Create a dictionary with 'name' as key and 'final_price' as value
                variation_price_dict = {item['variation']['name']: item['variation']['final_price'] for item in inventory_list}

                # Step 2: Find the single key-value pair for minimum and maximum prices
                min_key = min(variation_price_dict, key=variation_price_dict.get)  # Key with the minimum price
                max_key = max(variation_price_dict, key=variation_price_dict.get)  # Key with the maximum price

                # min_price_result = {min_key: variation_price_dict[min_key]}
                # max_price_result = {max_key: variation_price_dict[max_key]}
                min_price_result = variation_price_dict[min_key]
                max_price_result = variation_price_dict[max_key]

                if not variation_price_dict:
                    variation_price_dict = "NA"
                else:
                    variation_price_dict = json.dumps(variation_price_dict)
                if not min_price_result:
                    min_price_result = None
                # else:
                #     min_price_result = json.dumps(min_price_result)
                if not max_price_result:
                    max_price_result = None
                # else:
                #     max_price_result = json.dumps(max_price_result)

                # print("Price Dictionary:", variation_price_dict)
                # print("Minimum Price:", min_price_result)
                # print("Maximum Price:", max_price_result)

                supplier_name = re.sub(r'\s+', ' ', str(data['supplier_name']))

                stock_status = str(data['in_stock']).upper()
                if stock_status == "TRUE":
                    delivery_date,delivery_days = self.get_delivery_info()
                else:
                    delivery_date = "NA"

                item = MeeshoDesItemDaily()
                item['Super_Category_Name'] = Supercategory_Name
                item['Category_name'] = Category_name
                item['Sub_Category_Name'] = Subcategory_Name
                item['Seller_Data_Name'] = seller_name
                item['Category_URL'] = category_URL
                item['Product_Sku_Id'] = data['product_id']
                item['Product_Sku_Name'] = data['name'].strip().strip("\\")
                item['Product_Sku_Url'] = product_link
                item['Product_Images_Urls'] = ' | '.join(data['images'])
                item['Product_Count_of_Images'] = len(data['images'])
                item['Product_Rating'] = Product_Avg_Rating
                item['Product_Rating_Count'] = Product_Rating_Count
                item['Product_Review_Count'] = Product_Review_Count
                item['Product_Rating_Count_Map'] = str(rating_count_map)
                item['Product_Size'] = size_variant
                item['Product_Variation_Price'] = variation_price_dict
                item['Product_Variation_Min_Price'] = min_price_result
                item['Product_Variation_Max_Price'] = max_price_result
                item['Product_Details'] = normalize_spaces(data['description'])
                item['Product_Delivery_Charges'] = data['shipping']['charges']
                item['Product_In_Stock_Status'] = stock_status
                item['Product_Mrp'] = mrp
                item['Product_Price'] = original_price
                item['Product_Discounted_Price'] = discounted_price
                item['Product_Discount_Percent'] = discount_percentage
                item['Seller_Id'] = supplier_id
                item['Seller_Name'] = supplier_name
                item['Seller_Url'] = seller_url
                item['Seller_Rating'] = Seller_Avg_Rating
                item['Seller_Rating_Count'] = Seller_Rating_Count
                item['Seller_Followers_Count'] = Seller_Followers_Count
                item['Seller_Product_Count'] = Seller_Product_Count
                item['Product_Delivery_Date'] = delivery_date
                item['Product_Pincode'] = '781001'
                item['City'] = 'GUWAHATI'
                item['Scrape_Date'] = str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                # item['Scrape_Date'] = str((datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S"))
                # print(item)
                yield item
                if item['Product_Sku_Name']:
                    status = 'Done'
                    # update_query = f"update {db.db_links_table} set `status` = 'Done' where `product_link` = '{product_url}' AND `Subcategory_Name`='{Subcategory_Name}'"
                    update_query = f"update {db.db_links_table_daily} set `status` = '{status}' where `index` = '{index_id}'"
                    try:
                        self.cursor.execute(update_query)
                        # self.con.commit()
                    except Exception as e:
                        print(e)
            else:
                status = "Out Of Stock"
                # update_query = f"update {db.db_links_table} set `status` = '{status}' where `product_link` = '{product_url}' AND `Subcategory_Name`='{Subcategory_Name}'"
                update_query = f"update {db.db_links_table_daily} set `status` = '{status}' where `index` = '{index_id}'"

                try:
                    self.cursor.execute(update_query)
                    # self.con.commit()
                except Exception as e:
                    print(e)
        else:
            status = "Not Found Page"
            # update_query = f"update {db.db_links_table} set `status` = '{status}' where `product_link` = '{product_url}' AND `Subcategory_Name`='{Subcategory_Name}'"
            update_query = f"update {db.db_links_table_daily} set `status` = '{status}' where `index` = '{index_id}'"
            try:
                self.cursor.execute(update_query)
                # self.con.commit()
            except Exception as e:
                print(e)

    def close(self, reason):
        """Called when the spider finishes to export the final data to Excel."""
        count_query = f"Select * from {db.db_links_table_daily} where status='pending'"
        self.cursor.execute(count_query)
        pending_count = self.cursor.fetchall()
        if len(pending_count) == 0:
            print("Crawl Done...")
            # Call the method to export collected data to an Excel file
            file_generate_daily()
            status_update = f"UPDATE {db.db_links_table_daily} SET status='pending'"
            self.cursor.execute(status_update)
            self.con.commit()


if __name__ == '__main__':
    # execute("scrapy crawl product_data_des_daily -a start=73 -a end=74".split())
    execute("scrapy crawl product_data_des_daily -a start=1 -a end=1000".split())

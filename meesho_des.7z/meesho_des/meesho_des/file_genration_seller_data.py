import pandas as pd
import sqlalchemy
import meesho_des.db_config as db


def file_generate():
    # Database connection setup
    db_url = f"mysql+pymysql://{db.db_user}:{db.db_password}@{db.db_host}/{db.db_name}"  # Replace placeholders with your database details
    engine = sqlalchemy.create_engine(db_url)

    # SQL table read
    table_name = f"{db.db_data_table}"  # Replace with your table name
    query = f"SELECT * FROM {table_name}"

    # Read table into DataFrame
    df = pd.read_sql(query, engine)
    df = df.replace(r'^\s*$', None, regex=True)
    df['Product_Sku_Name'] = df['Product_Sku_Name'].str.replace(r'\s+', ' ', regex=True).str.strip()

    # Drop the unwanted column
    if 'Product_Pin_PageSave_Status' in df.columns:
        df = df.drop(columns=['Product_Pin_PageSave_Status'])

    # Fill missing values with "N/A"
    # df.fillna("N/A", inplace=True)
    # Drop columns where all values are "N/A"
    df = df.drop(columns=[col for col in df.columns if df[col].eq("N/A").all()])

    # Rename the header from 'Category_URL' to 'Base_Url'
    if 'Category_URL' in df.columns:
        df = df.rename(columns={'Category_URL': 'Base_Url'})


    # Write to Excel file
    output_file = f"Meesho_Seller_Desc_Data_{db.current_week}.xlsx"  # Name of the Excel file
    with pd.ExcelWriter(path=output_file, engine='xlsxwriter',
            engine_kwargs={"options": {'strings_to_urls': False}}) as writer:
        df.to_excel(writer, index=False)

    print(f"Excel file generated: {output_file}")

file_generate()
from slack_sdk import WebClient
from pathlib import Path
import json


# slack_bot_credentials_json: dict = json.loads(Path("./slack_bot_credentials.json").read_text(encoding="utf-8"))

# Initialize Slack client with your bot token
# slack_bot_token: str = slack_bot_credentials_json.get('slack_bot_token', 'NA')  # Replace with your bot token
# daily_msgs_channel_id: str = slack_bot_credentials_json.get('daily_msgs_channel_id', 'NA')  # Replace with your bot token


def send_slack_message(slack_bot_token, message, channel_id):
    """Send a message to Slack channel."""
    slack_client = WebClient(token=slack_bot_token)
    try:
        slack_client.chat_postMessage(channel=channel_id, text=message)
        print(f"Message sent to Slack: {message}")
    except Exception as e:
        slack_client.chat_postMessage(channel=channel_id, text=f"Failed to send message to Slack: {e}")
        print(f"Failed to send message to Slack: {e}")

# send_slack_message(slack_bot_token=slack_bot_token, message='test message', channel_id=daily_msgs_channel_id)

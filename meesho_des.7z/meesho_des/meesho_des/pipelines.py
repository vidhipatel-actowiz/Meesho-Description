# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from datetime import datetime
import meesho_des.db_config as db
from meesho_des.items import *
DATE = str(datetime.now().strftime("%Y%m%d"))
# DATE = "20250108"


class MeeshoDesPipeline:
    def process_item(self, item, spider):
        print(spider.name)
        if spider.name == 'product_data_des_daily':
            db_data_table = db.db_data_table_daily
        else:
            db_data_table = db.db_data_table
        create_table_pdp = f'''
            CREATE TABLE IF NOT EXISTS `{db_data_table}` (
                `id` INT NOT NULL AUTO_INCREMENT,
                `Super_Category_Name` VARCHAR(255) DEFAULT NULL,
                `Category_name` VARCHAR(255) DEFAULT NULL,
                `Sub_Category_Name` VARCHAR(255) DEFAULT NULL,
                `Seller_Data_Name` text DEFAULT NULL,
                `Category_URL` text DEFAULT NULL,
                `Product_Sku_Id` VARCHAR(255) DEFAULT NULL,
                `Product_Sku_Name` text DEFAULT NULL,
                `Product_Sku_Url` text DEFAULT NULL,
                `Product_Images_Urls` text DEFAULT NULL,
                `Product_Count_of_Images` INT DEFAULT NULL,
                `Product_Rating` FLOAT DEFAULT NULL,
                `Product_Rating_Count` INT DEFAULT NULL,                    
                `Product_Review_Count` INT DEFAULT NULL,                  
                `Product_Rating_Count_Map` VARCHAR(255) DEFAULT NULL,                  
                `Product_Size` text DEFAULT NULL,                  
                `Product_Variation_Price` text DEFAULT NULL,                  
                `Product_Variation_Min_Price` FLOAT DEFAULT NULL,                  
                `Product_Variation_Max_Price` FLOAT DEFAULT NULL,                  
                `Product_Details` text DEFAULT NULL,  
                `Product_Delivery_Charges` FLOAT DEFAULT NULL,
                `Product_In_Stock_Status` VARCHAR(255) DEFAULT NULL,
                `Product_Mrp` FLOAT DEFAULT NULL,                 
                `Product_Price` FLOAT DEFAULT NULL,                 
                `Product_Discounted_Price` FLOAT DEFAULT NULL, 
                `Product_Discount_Percent` FLOAT DEFAULT NULL,                
                `Seller_Id` VARCHAR(255) DEFAULT NULL,
                `Seller_Name` VARCHAR(255) DEFAULT NULL,
                `Seller_Url` VARCHAR(255) DEFAULT NULL,
                `Seller_Rating` FLOAT DEFAULT NULL,   
                `Seller_Rating_Count` INT DEFAULT NULL,
                `Seller_Followers_Count` INT DEFAULT NULL,
                `Seller_Product_Count` INT DEFAULT NULL,                 
                `Product_Delivery_Date` VARCHAR(255) DEFAULT NULL,
                `Product_Pincode` INT DEFAULT NULL,
                `City` VARCHAR(255) DEFAULT NULL,                
                `Product_Pin_PageSave_Status` VARCHAR(255) DEFAULT 'pending',
                `Scrape_Date` VARCHAR(255) DEFAULT NULL,
                PRIMARY KEY (`id`)
            );
        '''

        spider.cursor.execute(create_table_pdp)
        spider.con.commit()

        # create_table_seller_pro_link = f'''
        #                     CREATE TABLE IF NOT EXISTS `{db.seller_db_pro_links_table}` (
        #                         `id` INT NOT NULL AUTO_INCREMENT,
        #                         `seller_name` TEXT DEFAULT NULL,
        #                         `base_url` TEXT DEFAULT NULL,
        #                         `product_url` TEXT DEFAULT NULL,
        #                         `Status` VARCHAR(255) DEFAULT 'Pending',
        #                         PRIMARY KEY (`id`)
        #                     );
        #                 '''
        # spider.cursor.execute(create_table_seller_pro_link)
        # spider.con.commit()

        if isinstance(item, MeeshoDesItem):

            try:
                # Id = item.pop('Id')
                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append('%s')
                fields = ','.join(field_list)
                values = ", ".join(value_list)
                insert_db = f"insert into {db.db_data_table}( " + fields + " ) values ( " + values + " )"

                try:
                    # status = "Done"
                    values_data = item.values()
                    row_dict = dict(zip(item.keys(), values_data))
                    # print(row_dict)
                    Product_Sku_Id = row_dict.get('Product_Sku_Id')
                    spider.cursor.execute(insert_db, tuple(item.values()))
                    spider.logger.info(f'Data Inserted...')
                    # print(f'https://www.meesho.com/s/p/{Product_Sku_Id}?utm_source=s')
                    url = f'https://www.meesho.com/s/p/{Product_Sku_Id}?utm_source=s'

                except Exception as e:
                    print(e)
            except Exception as e:
                print(e)

        if isinstance(item, MeeshoDesItemDaily):

            try:
                # Id = item.pop('Id')
                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append('%s')
                fields = ','.join(field_list)
                values = ", ".join(value_list)
                insert_db = f"insert into {db.db_data_table_daily}( " + fields + " ) values ( " + values + " )"

                try:
                    # status = "Done"
                    values_data = item.values()
                    row_dict = dict(zip(item.keys(), values_data))
                    # print(row_dict)
                    Product_Sku_Id = row_dict.get('Product_Sku_Id')
                    spider.cursor.execute(insert_db, tuple(item.values()))
                    spider.logger.info(f'Data Inserted...')
                    # print(f'https://www.meesho.com/s/p/{Product_Sku_Id}?utm_source=s')
                    url = f'https://www.meesho.com/s/p/{Product_Sku_Id}?utm_source=s'

                except Exception as e:
                    print(e)
            except Exception as e:
                print(e)

        # if isinstance(item, MeeshoDesSellerLinkItem):
        #     try:
        #         # Id = item.pop('Id')
        #         field_list = []
        #         value_list = []
        #         for field in item:
        #             field_list.append(str(field))
        #             value_list.append('%s')
        #         fields = ','.join(field_list)
        #         values = ", ".join(value_list)
        #         insert_db = f"insert into {db.seller_db_pro_links_table}( " + fields + " ) values ( " + values + " )"
        #
        #         try:
        #             # status = "Done"
        #             # values_data = item.values()
        #             # row_dict = dict(zip(item.keys(), values_data))
        #             # print(row_dict)
        #             # Product_Sku_Id = row_dict.get('Product_Sku_Id')
        #             spider.cursor.execute(insert_db, tuple(item.values()))
        #             spider.logger.info(f'Data Inserted...')
        #             # print(f'https://www.meesho.com/s/p/{Product_Sku_Id}?utm_source=s')
        #             # url = f'https://www.meesho.com/s/p/{Product_Sku_Id}?utm_source=s'
        #
        #         except Exception as e:
        #             print(e)
        #     except Exception as e:
        #         print(e)
